<?php
/**
 * @package    mod_panorama4net
 * @author     Design4Net (Sergey Kupletsky)
 * @copyright  Copyright by Design4Net (C) 2013. All rights reserved.
 * @license    GNU General Public License version 2 or later
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Image Params

//--// Module Id
$mod_id = $params->get('modId');

//--// Url and size of image
$image_url = JURI::base().$params->get('imagePath');
$imageSize = getimagesize($image_url);

//--// Image Name
$imagePath = pathinfo($image_url);
$image_name = $imagePath[filename];

//--// Height and Width of Image
$img = ImageCreateFromJpeg($image_url);
$image_height = ImageSY($img);
$image_width = ImageSX($img);

//--// Image Alt and Title
$image_title = $params->get('imageTitle');
$image_alt = $params->get('imageAlt');

// Panorama Params

//--// Panorama CSS Style
$panorama_style = $params->get('panoramaStyle');

//--// Panorama Caption
$panorama_caption = $params->get('panoramaCaption');
$panorama_title = $params->get('panoramaTitle');
$bbCode = array("[", "]");
$htmlCode   = array("<", ">");
$panorama_title = str_replace($bbCode, $htmlCode, $panorama_title);

//--// Auto start
$auto_start = $params->get('autoStart');

//--// Direction
$direction = $params->get('direction');

//--// Speed
$speed = $params->get('speed');

//--// Start position
$start_pos = $params->get('startPosition');

//--// Width and height of displayed view
$width = $params->get('panoramaWidth');
$height = $params->get('panoramaHeight');

//--// Display control buttons
$control = $params->get('controlDisplay');
$control_vertical = $params->get('controlVertical');
$control_horizontal = $params->get('controlHorizontal');
$control_style = $params->get('controlStyle');

//--//  load jquery
$loadJquery = $params->get('loadJquery'); // default is yes

//--//  load FontAwesome
$loadFont = $params->get('loadFont'); // default is yes

//--//  load Modernizr
$loadModernizr = $params->get('loadModernizr'); // default is yes

// load stylesheets and scripts for this module
$doc = &JFactory::getDocument();

if ($loadJquery) {
	$doc->addScript('http://ajax.googleapis.com/ajax/libs/jquery/'.$loadJquery.'/jquery.min.js');
    $doc->addScript('modules/mod_panorama4net/js/jquery-noconflict.js');
}
if ($loadFont == 1) {
    $doc->addStyleSheet('http://netdna.bootstrapcdn.com/font-awesome/3.2.0/css/font-awesome.min.css');
}
if ($loadModernizr == 1) {
    $doc->addScript('modules/mod_panorama4net/js/modernizr.custom.29293.js');
}

//$doc->addScript('modules/mod_panorama4net/js/jquery.easing.min.js');

$doc->addStyleSheet('modules/mod_panorama4net/css/base.css');
$doc->addStyleSheet('modules/mod_panorama4net/css/style/'.$panorama_style.'.css');

$doc->addScript('modules/mod_panorama4net/js/jquery.touch.support.js');
$doc->addScript('modules/mod_panorama4net/js/jquery.mousewheel.js');
$doc->addScript('modules/mod_panorama4net/js/jquery.panorama4net.js');


$layout = $params->get('layout');
require JmoduleHelper::getLayoutPath('mod_panorama4net', $layout); // load layout and display it
?>
